package com.team.app.service.impl;

import com.team.app.dao.UserDao;
import com.team.app.dao.impl.UserDaoImpl;
import com.team.app.domain.User;
import com.team.app.service.AuthService;
import org.mindrot.jbcrypt.BCrypt;

import java.sql.SQLException;
import java.util.Optional;

public class AuthServiceImpl implements AuthService {
    private final UserDao userDao = new UserDaoImpl();

    @Override
    public Optional<User> login(String email, String passwordPlain) {
        try {
            return userDao.findByEmail(email).filter(u -> BCrypt.checkpw(passwordPlain, u.passwordHash()));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public User register(String email, String displayName, String passwordPlain) {
        try {
            String hash = BCrypt.hashpw(passwordPlain, BCrypt.gensalt(10));
            return userDao.create(email, displayName, hash);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}