package com.team.app.domain;

public record Card(int id, int deckId, String frontText, String backText) {}