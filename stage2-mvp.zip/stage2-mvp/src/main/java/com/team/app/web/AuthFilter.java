package com.team.app.web;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class AuthFilter implements Filter {
    @Override public void init(FilterConfig filterConfig) {}
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        var req = (HttpServletRequest) request;
        var res = (HttpServletResponse) response;
        Object user = req.getSession().getAttribute("user");
        String path = req.getRequestURI();
        if (path.startsWith(req.getContextPath() + "/app/") && user == null) {
            res.sendRedirect(req.getContextPath() + "/auth/login");
            return;
        }
        chain.doFilter(request, response);
    }
    @Override public void destroy() {}
}