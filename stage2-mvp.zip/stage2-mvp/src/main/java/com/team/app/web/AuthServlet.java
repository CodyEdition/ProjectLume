package com.team.app.web;

import com.team.app.domain.User;
import com.team.app.service.AuthService;
import com.team.app.service.impl.AuthServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.Optional;

public class AuthServlet extends HttpServlet {
    private final AuthService auth = new AuthServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String path = req.getPathInfo();
        if (path == null || "/login".equals(path)) {
            req.getRequestDispatcher("/WEB-INF/jsp/login.jsp").forward(req, resp);
        } else if ("/register".equals(path)) {
            req.getRequestDispatcher("/WEB-INF/jsp/register.jsp").forward(req, resp);
        } else if ("/logout".equals(path)) {
            req.getSession().invalidate();
            resp.sendRedirect(req.getContextPath()+"/");
        } else {
            resp.sendError(404);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String path = req.getPathInfo();
        if ("/login".equals(path)) {
            String email = req.getParameter("email");
            String pass = req.getParameter("password");
            Optional<User> u = auth.login(email, pass);
            if (u.isPresent()) {
                req.getSession().setAttribute("user", u.get());
                resp.sendRedirect(req.getContextPath()+"/app/decks");
            } else {
                req.setAttribute("error", "Invalid credentials");
                doGet(req, resp);
            }
        } else if ("/register".equals(path)) {
            String email = req.getParameter("email");
            String name  = req.getParameter("displayName");
            String pass  = req.getParameter("password");
            User u = auth.register(email, name, pass);
            req.getSession().setAttribute("user", u);
            resp.sendRedirect(req.getContextPath()+"/app/decks");
        } else {
            resp.sendError(404);
        }
    }
}