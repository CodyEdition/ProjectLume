package com.team.app.dao;

import com.team.app.domain.Deck;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public interface DeckDao {
    List<Deck> findByOwner(int ownerId) throws SQLException;
    Optional<Deck> findOne(int id, int ownerId) throws SQLException;
    Deck create(int ownerId, String title, String description) throws SQLException;
    boolean update(int id, int ownerId, String title, String description) throws SQLException;
    boolean delete(int id, int ownerId) throws SQLException;
}