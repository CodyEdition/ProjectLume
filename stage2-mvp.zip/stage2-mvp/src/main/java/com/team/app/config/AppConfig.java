package com.team.app.config;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import java.sql.DriverManager;

public class AppConfig implements ServletContextListener {
    public static String JDBC_URL;
    public static String JDBC_USER;
    public static String JDBC_PASS;

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        JDBC_URL  = sce.getServletContext().getInitParameter("JDBC_URL");
        JDBC_USER = sce.getServletContext().getInitParameter("JDBC_USER");
        JDBC_PASS = sce.getServletContext().getInitParameter("JDBC_PASS");
        try {
            Class.forName("org.hsqldb.jdbcDriver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("HSQLDB driver not found", e);
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {}
}