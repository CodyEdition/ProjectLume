package com.team.app.domain;

public record Deck(int id, int ownerId, String title, String description) {}