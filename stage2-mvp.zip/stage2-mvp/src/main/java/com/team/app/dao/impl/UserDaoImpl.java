package com.team.app.dao.impl;

import com.team.app.config.ConnectionFactory;
import com.team.app.dao.UserDao;
import com.team.app.domain.User;

import java.sql.*;
import java.util.Optional;

public class UserDaoImpl implements UserDao {
    @Override
    public Optional<User> findByEmail(String email) throws SQLException {
        String sql = "SELECT id, email, display_name, password_hash FROM users WHERE email=?";
        try (Connection c = ConnectionFactory.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(map(rs));
                }
                return Optional.empty();
            }
        }
    }

    @Override
    public Optional<User> findById(int id) throws SQLException {
        String sql = "SELECT id, email, display_name, password_hash FROM users WHERE id=?";
        try (Connection c = ConnectionFactory.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(map(rs));
                return Optional.empty();
            }
        }
    }

    @Override
    public User create(String email, String displayName, String passwordHash) throws SQLException {
        String sql = "INSERT INTO users(email, display_name, password_hash) VALUES(?,?,?)";
        try (Connection c = ConnectionFactory.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, email);
            ps.setString(2, displayName);
            ps.setString(3, passwordHash);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                keys.next();
                int id = keys.getInt(1);
                return new User(id, email, displayName, passwordHash);
            }
        }
    }

    private User map(ResultSet rs) throws SQLException {
        return new User(
                rs.getInt("id"),
                rs.getString("email"),
                rs.getString("display_name"),
                rs.getString("password_hash")
        );
    }
}