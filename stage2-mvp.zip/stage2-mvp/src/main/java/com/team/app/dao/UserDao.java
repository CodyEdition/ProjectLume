package com.team.app.dao;

import com.team.app.domain.User;
import java.sql.SQLException;
import java.util.Optional;

public interface UserDao {
    Optional<User> findByEmail(String email) throws SQLException;
    Optional<User> findById(int id) throws SQLException;
    User create(String email, String displayName, String passwordHash) throws SQLException;
}