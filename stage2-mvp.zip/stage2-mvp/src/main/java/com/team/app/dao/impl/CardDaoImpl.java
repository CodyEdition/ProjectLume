package com.team.app.dao.impl;

import com.team.app.config.ConnectionFactory;
import com.team.app.dao.CardDao;
import com.team.app.domain.Card;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CardDaoImpl implements CardDao {
    @Override
    public List<Card> list(int deckId, int ownerId) throws SQLException {
        String sql = "SELECT c.id, c.deck_id, c.front_text, c.back_text " +
                     "FROM cards c JOIN decks d ON c.deck_id=d.id " +
                     "WHERE c.deck_id=? AND d.owner_id=? ORDER BY c.id DESC";
        try (Connection c = ConnectionFactory.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, deckId);
            ps.setInt(2, ownerId);
            try (ResultSet rs = ps.executeQuery()) {
                List<Card> out = new ArrayList<>();
                while (rs.next()) {
                    out.add(new Card(
                        rs.getInt("id"),
                        rs.getInt("deck_id"),
                        rs.getString("front_text"),
                        rs.getString("back_text")
                    ));
                }
                return out;
            }
        }
    }

    @Override
    public Card create(int deckId, int ownerId, String front, String back) throws SQLException {
        // Ownership enforced by join select
        String guard = "SELECT 1 FROM decks WHERE id=? AND owner_id=?";
        try (Connection c = ConnectionFactory.getConnection();
             PreparedStatement g = c.prepareStatement(guard)) {
            g.setInt(1, deckId); g.setInt(2, ownerId);
            try (ResultSet rs = g.executeQuery()) {
                if (!rs.next()) throw new SQLException("Deck not found or not owned by user");
            }
        }
        String sql = "INSERT INTO cards(deck_id, front_text, back_text) VALUES(?,?,?)";
        try (Connection c = ConnectionFactory.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, deckId);
            ps.setString(2, front);
            ps.setString(3, back);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                keys.next();
                int id = keys.getInt(1);
                return new Card(id, deckId, front, back);
            }
        }
    }

    @Override
    public boolean update(int id, int deckId, int ownerId, String front, String back) throws SQLException {
        String sql = "UPDATE cards SET front_text=?, back_text=? WHERE id=? AND deck_id=? AND EXISTS (SELECT 1 FROM decks d WHERE d.id=? AND d.owner_id=?)";
        try (Connection c = ConnectionFactory.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, front);
            ps.setString(2, back);
            ps.setInt(3, id);
            ps.setInt(4, deckId);
            ps.setInt(5, deckId);
            ps.setInt(6, ownerId);
            return ps.executeUpdate() == 1;
        }
    }

    @Override
    public boolean delete(int id, int deckId, int ownerId) throws SQLException {
        String sql = "DELETE FROM cards WHERE id=? AND deck_id=? AND EXISTS (SELECT 1 FROM decks d WHERE d.id=? AND d.owner_id=?)";
        try (Connection c = ConnectionFactory.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.setInt(2, deckId);
            ps.setInt(3, deckId);
            ps.setInt(4, ownerId);
            return ps.executeUpdate() == 1;
        }
    }
}