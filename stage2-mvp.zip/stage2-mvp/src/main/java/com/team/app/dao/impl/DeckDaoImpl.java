package com.team.app.dao.impl;

import com.team.app.config.ConnectionFactory;
import com.team.app.dao.DeckDao;
import com.team.app.domain.Deck;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class DeckDaoImpl implements DeckDao {
    @Override
    public List<Deck> findByOwner(int ownerId) throws SQLException {
        String sql = "SELECT id, owner_id, title, description FROM decks WHERE owner_id=? ORDER BY id DESC";
        try (Connection c = ConnectionFactory.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, ownerId);
            try (ResultSet rs = ps.executeQuery()) {
                List<Deck> out = new ArrayList<>();
                while (rs.next()) out.add(map(rs));
                return out;
            }
        }
    }

    @Override
    public Optional<Deck> findOne(int id, int ownerId) throws SQLException {
        String sql = "SELECT id, owner_id, title, description FROM decks WHERE id=? AND owner_id=?";
        try (Connection c = ConnectionFactory.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.setInt(2, ownerId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(map(rs));
                return Optional.empty();
            }
        }
    }

    @Override
    public Deck create(int ownerId, String title, String description) throws SQLException {
        String sql = "INSERT INTO decks(owner_id, title, description) VALUES(?,?,?)";
        try (Connection c = ConnectionFactory.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, ownerId);
            ps.setString(2, title);
            ps.setString(3, description);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                keys.next();
                int id = keys.getInt(1);
                return new Deck(id, ownerId, title, description);
            }
        }
    }

    @Override
    public boolean update(int id, int ownerId, String title, String description) throws SQLException {
        String sql = "UPDATE decks SET title=?, description=? WHERE id=? AND owner_id=?";
        try (Connection c = ConnectionFactory.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, title);
            ps.setString(2, description);
            ps.setInt(3, id);
            ps.setInt(4, ownerId);
            return ps.executeUpdate() == 1;
        }
    }

    @Override
    public boolean delete(int id, int ownerId) throws SQLException {
        String sql = "DELETE FROM decks WHERE id=? AND owner_id=?";
        try (Connection c = ConnectionFactory.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.setInt(2, ownerId);
            return ps.executeUpdate() == 1;
        }
    }

    private Deck map(ResultSet rs) throws SQLException {
        return new Deck(
                rs.getInt("id"),
                rs.getInt("owner_id"),
                rs.getString("title"),
                rs.getString("description")
        );
    }
}