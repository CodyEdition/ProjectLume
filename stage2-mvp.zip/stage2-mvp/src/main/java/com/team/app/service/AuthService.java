package com.team.app.service;

import com.team.app.domain.User;
import java.util.Optional;

public interface AuthService {
    Optional<User> login(String email, String passwordPlain);
    User register(String email, String displayName, String passwordPlain);
}