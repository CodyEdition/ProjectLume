package com.team.app.web;

import com.team.app.dao.CardDao;
import com.team.app.dao.impl.CardDaoImpl;
import com.team.app.domain.Card;
import com.team.app.domain.User;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public class CardServlet extends HttpServlet {
    private final CardDao cards = new CardDaoImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User u = (User) req.getSession().getAttribute("user");
        String deckIdStr = req.getParameter("deckId");
        if (deckIdStr == null) { resp.sendError(400, "deckId required"); return; }
        int deckId = Integer.parseInt(deckIdStr);
        try {
            List<Card> list = cards.list(deckId, u.id());
            req.setAttribute("cards", list);
            req.setAttribute("deckId", deckId);
            req.getRequestDispatcher("/WEB-INF/jsp/cards.jsp").forward(req, resp);
        } catch (SQLException e) { throw new ServletException(e); }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User u = (User) req.getSession().getAttribute("user");
        int deckId = Integer.parseInt(req.getParameter("deckId"));
        String front = req.getParameter("front");
        String back  = req.getParameter("back");
        try {
            cards.create(deckId, u.id(), front, back);
            resp.sendRedirect(req.getContextPath()+"/app/cards?deckId="+deckId);
        } catch (Exception e) { throw new ServletException(e); }
    }
}