package com.team.app.dao;

import com.team.app.domain.Card;
import java.sql.SQLException;
import java.util.List;

public interface CardDao {
    List<Card> list(int deckId, int ownerId) throws SQLException;
    Card create(int deckId, int ownerId, String front, String back) throws SQLException;
    boolean update(int id, int deckId, int ownerId, String front, String back) throws SQLException;
    boolean delete(int id, int deckId, int ownerId) throws SQLException;
}