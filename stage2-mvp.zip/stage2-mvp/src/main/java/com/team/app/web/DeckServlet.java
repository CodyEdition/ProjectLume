package com.team.app.web;

import com.team.app.dao.DeckDao;
import com.team.app.dao.impl.DeckDaoImpl;
import com.team.app.domain.Deck;
import com.team.app.domain.User;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public class DeckServlet extends HttpServlet {
    private final DeckDao decks = new DeckDaoImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User u = (User) req.getSession().getAttribute("user");
        String path = req.getPathInfo();
        if (path == null || "/".equals(path) || "/list".equals(path)) {
            try {
                List<Deck> list = decks.findByOwner(u.id());
                req.setAttribute("decks", list);
                req.getRequestDispatcher("/WEB-INF/jsp/decks.jsp").forward(req, resp);
            } catch (SQLException e) { throw new ServletException(e); }
        } else if ("/new".equals(path)) {
            req.getRequestDispatcher("/WEB-INF/jsp/deckForm.jsp").forward(req, resp);
        } else {
            resp.sendError(404);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User u = (User) req.getSession().getAttribute("user");
        String title = req.getParameter("title");
        String desc  = req.getParameter("description");
        try {
            decks.create(u.id(), title, desc);
            resp.sendRedirect(req.getContextPath()+"/app/decks");
        } catch (Exception e) { throw new ServletException(e); }
    }
}