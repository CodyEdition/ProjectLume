package com.team.app.domain;

public record User(int id, String email, String displayName, String passwordHash) {}