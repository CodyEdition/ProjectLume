package com.team.app.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(AppConfig.JDBC_URL, AppConfig.JDBC_USER, AppConfig.JDBC_PASS);
    }
}