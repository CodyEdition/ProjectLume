<%@ page session="true" %>
<%
  Object user = session.getAttribute("user");
%>
<!doctype html>
<html><head><title>Stage2 MVP</title></head>
<body>
<h1>Stage2 MVP</h1>
<% if (user == null) { %>
  <p><a href="<%=request.getContextPath()%>/auth/login">Login</a> or
     <a href="<%=request.getContextPath()%>/auth/register">Register</a></p>
<% } else { %>
  <p><a href="<%=request.getContextPath()%>/app/decks">My Decks</a> |
     <a href="<%=request.getContextPath()%>/auth/logout">Logout</a></p>
<% } %>
</body></html>