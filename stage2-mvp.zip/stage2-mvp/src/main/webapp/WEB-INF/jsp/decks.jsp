<%@ page import="java.util.*,com.team.app.domain.Deck" %>
<%@ page session="true" %>
<!doctype html>
<html><head><title>My Decks</title></head>
<body>
<h2>My Decks</h2>
<ul>
<%
  List<Deck> decks = (List<Deck>) request.getAttribute("decks");
  for (Deck d : decks) {
%>
  <li><strong><%=d.title()%></strong> - <%=d.description()%>
      [<a href="<%=request.getContextPath()%>/app/cards?deckId=<%=d.id()%>">Open</a>]
  </li>
<% } %>
</ul>

<h3>New Deck</h3>
<form method="post" action="<%=request.getContextPath()%>/app/decks">
  <label>Title <input type="text" name="title" required></label><br>
  <label>Description <input type="text" name="description"></label><br>
  <button type="submit">Create</button>
</form>
<p><a href="<%=request.getContextPath()%>/">Home</a></p>
</body></html>