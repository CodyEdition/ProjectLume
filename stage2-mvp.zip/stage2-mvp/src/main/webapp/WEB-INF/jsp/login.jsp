<%@ page session="false" %>
<!doctype html>
<html><head><title>Login</title></head>
<body>
<h2>Login</h2>
<form method="post" action="<%=request.getContextPath()%>/auth/login">
  <label>Email <input type="email" name="email" required></label><br>
  <label>Password <input type="password" name="password" required></label><br>
  <button type="submit">Login</button>
</form>
<% String err=(String)request.getAttribute("error"); if(err!=null){ %>
<p style="color:red"><%=err%></p>
<% } %>
<p>No account? <a href="<%=request.getContextPath()%>/auth/register">Register</a></p>
</body></html>