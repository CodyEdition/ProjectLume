<%@ page session="false" %>
<!doctype html>
<html><head><title>Register</title></head>
<body>
<h2>Register</h2>
<form method="post" action="<%=request.getContextPath()%>/auth/register">
  <label>Email <input type="email" name="email" required></label><br>
  <label>Display Name <input type="text" name="displayName" required></label><br>
  <label>Password <input type="password" name="password" required></label><br>
  <button type="submit">Create Account</button>
</form>
<p>Have an account? <a href="<%=request.getContextPath()%>/auth/login">Login</a></p>
</body></html>