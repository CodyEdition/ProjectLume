<%@ page import="java.util.*,com.team.app.domain.Card" %>
<%@ page session="true" %>
<!doctype html>
<html><head><title>Cards</title></head>
<body>
<h2>Cards</h2>
<ul>
<%
  List<Card> cards = (List<Card>) request.getAttribute("cards");
  for (Card c : cards) {
%>
  <li><strong><%=c.frontText()%></strong> — <%=c.backText()%></li>
<% } %>
</ul>

<h3>Add Card</h3>
<form method="post" action="<%=request.getContextPath()%>/app/cards">
  <input type="hidden" name="deckId" value="<%=request.getAttribute("deckId")%>">
  <label>Front <input type="text" name="front" required></label><br>
  <label>Back <input type="text" name="back" required></label><br>
  <button type="submit">Add</button>
</form>
<p><a href="<%=request.getContextPath()%>/app/decks">Back to Decks</a></p>
</body></html>